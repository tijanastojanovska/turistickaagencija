package com.example.turistickaagencija.exceptions;

public class PasswordsDoNotMatchException extends RuntimeException {
}
