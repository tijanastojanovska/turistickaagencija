package com.example.turistickaagencija.web;


import com.example.turistickaagencija.model.Destinacija;
import com.example.turistickaagencija.model.Kompanija;
import com.example.turistickaagencija.model.Linija;
import com.example.turistickaagencija.service.DestinacijaService;
import com.example.turistickaagencija.service.KompanijaService;
import com.example.turistickaagencija.service.LinijaService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class DestinacijaController {
    private final LinijaService linijaService;
    private final DestinacijaService destinacijaService;
    private final KompanijaService kompanijaService;

    public DestinacijaController(LinijaService linijaService, DestinacijaService destinacijaService, KompanijaService kompanijaService) {
        this.linijaService = linijaService;
        this.destinacijaService = destinacijaService;
        this.kompanijaService = kompanijaService;
    }


    @GetMapping("/destinacii")
    public String showDestinacii(@RequestParam(required = false) String name, Model model) {
        List<Destinacija> destinacii;
       if (name == null) {
            destinacii= this.destinacijaService.listAll();
       } else {
            destinacii= this.destinacijaService.listAllByIme(name);
        }

        model.addAttribute("destinacii",destinacii);
        model.addAttribute("bodyContent","listDestinacii");
        return "master-template";
    }
    @GetMapping("/destinacii/add")
    public String showAdd(Model model) {
        List<Destinacija> destinacii=this.destinacijaService.listAll();
        model.addAttribute("destinacii",destinacii);
        model.addAttribute("bodyContent","addDestinacii");
        return "master-template";

    }
    @GetMapping("/destinacii/{id}/edit")
    public String showEdit(@PathVariable Long id, Model model) {
        Destinacija destinacija = this.destinacijaService.findById(id);
        List<Destinacija> destinacii=this.destinacijaService.listAll();
        List<Kompanija> kompanii=this.kompanijaService.listAll();
        model.addAttribute("kompanii",kompanii);
        model.addAttribute("destinacii",destinacii);
        model.addAttribute("destinacija",destinacija);
        model.addAttribute("bodyContent","editDestinacii");
        return "master-template";

    }

    @PostMapping("/destinacii")
    public String create(@RequestParam String ime, @RequestParam String drzhava){
        this.destinacijaService.create(ime,drzhava);
        return "redirect:/destinacii";
    }
    @PostMapping("/destinacii/{id}")
    public String update(@PathVariable Long id,
                         @RequestParam String ime, @RequestParam String drzhava) {
        this.destinacijaService.update(id,ime,drzhava);
        return "redirect:/destinacii";
    }
    @PostMapping("/destinacii/{id}/delete")
    public String delete(@PathVariable Long id) {
        this.destinacijaService.delete(id);
        return "redirect:/destinacii";
    }
}
