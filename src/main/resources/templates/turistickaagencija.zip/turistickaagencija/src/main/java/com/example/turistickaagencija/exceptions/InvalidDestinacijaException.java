package com.example.turistickaagencija.exceptions;

public class InvalidDestinacijaException  extends RuntimeException{
}
