package com.example.turistickaagencija.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Destinacija {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_destinacija;
    private String ime_destinacija;
    private String drzhava;

    public Destinacija() {

    }

    public Destinacija(String ime_destinacija, String drzhava) {
        this.ime_destinacija = ime_destinacija;
        this.drzhava = drzhava;
    }

    public Long getId_destinacija() {
        return id_destinacija;
    }

    public void setId_destinacija(Long id_destinacija) {
        this.id_destinacija = id_destinacija;
    }

    public String getIme_destinacija() {
        return ime_destinacija;
    }

    public void setIme_destinacija(String ime_destinacija) {
        this.ime_destinacija = ime_destinacija;
    }

    public String getDrzhava() {
        return drzhava;
    }

    public void setDrzhava(String drzhava) {
        this.drzhava = drzhava;
    }
}
