package com.example.turistickaagencija.exceptions;

public class InvalidKompanijaException extends RuntimeException{
}
