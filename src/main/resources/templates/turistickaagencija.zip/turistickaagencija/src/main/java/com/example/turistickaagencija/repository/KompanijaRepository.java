package com.example.turistickaagencija.repository;

import com.example.turistickaagencija.model.Kompanija;
import org.springframework.data.jpa.repository.JpaRepository;

public interface KompanijaRepository extends JpaRepository<Kompanija,Long> {
}
