package com.example.turistickaagencija.exceptions;

public class InvalidUsernameOrPasswordException extends RuntimeException{
}
