package com.example.turistickaagencija.service.impl;

import com.example.turistickaagencija.exceptions.InvalidLinijaIdException;
import com.example.turistickaagencija.model.Destinacija;
import com.example.turistickaagencija.model.Kompanija;
import com.example.turistickaagencija.model.Linija;
import com.example.turistickaagencija.repository.DestinacijaRepository;
import com.example.turistickaagencija.repository.KompanijaRepository;
import com.example.turistickaagencija.repository.LinijaRepository;
import com.example.turistickaagencija.service.LinijaService;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
public class LinijaServiceImpl implements LinijaService {
    private final LinijaRepository linijaRepository;
    private final DestinacijaRepository destinacijaRepository;
    private final KompanijaRepository kompanijaRepository;


    public LinijaServiceImpl(LinijaRepository linijaRepository, DestinacijaRepository destinacijaRepository, KompanijaRepository kompanijaRepository) {
        this.linijaRepository = linijaRepository;
        this.destinacijaRepository = destinacijaRepository;
        this.kompanijaRepository = kompanijaRepository;
    }

    @Override
    public Linija create(float cena, Long pocetna, Long krajna,List<Long> kompanii) {
       Destinacija p=this.destinacijaRepository.findById(pocetna).get();
       Destinacija k=this.destinacijaRepository.findById(krajna).get();
        List<Kompanija> komp = this.kompanijaRepository.findAllById(kompanii);
        Linija linija=new Linija(cena,p,k,komp);
        return this.linijaRepository.save(linija);
    }

    @Override
    public Linija update(Long id,float cena,Long pocetna, Long krajna, List<Long> kompanii) {
        Linija linija = this.findById(id);
        linija.setCena(cena);
        Destinacija p=this.destinacijaRepository.findById(pocetna).get();
        Destinacija k=this.destinacijaRepository.findById(krajna).get();
        linija.setPocetna(p);
        linija.setKrajna(k);
        List<Kompanija> komp = this.kompanijaRepository.findAllById(kompanii);
        linija.setKompanii(komp);
        return this.linijaRepository.save(linija);
    }

    @Override
    public List<Linija> listAllLinii() {
        return this.linijaRepository.findAll();
    }

    @Override
    public Linija findById(Long id) {
        return this.linijaRepository.findById(id).orElseThrow(InvalidLinijaIdException::new);


    }



    @Override
    public Linija delete(Long id) {
        Linija linija = this.findById(id);
        this.linijaRepository.delete(linija);
        return linija;
    }

    @Override
    public List<Linija> listLiniiByDestinacii(Long destinacijaId) {
        Destinacija destinacija = destinacijaId != null ? this.destinacijaRepository.findById(destinacijaId).orElse((Destinacija) null) : null;
List<Linija> linii=new ArrayList<>();
if(!this.linijaRepository.findAllByKrajna(destinacija).isEmpty())
       linii.addAll(this.linijaRepository.findAllByKrajna(destinacija));
        if(!this.linijaRepository.findAllByPocetna(destinacija).isEmpty())
            linii.addAll(this.linijaRepository.findAllByPocetna(destinacija));
    return linii;


    }
}

