package com.example.turistickaagencija.enumerations;


public enum Status {
    CREATED,
    CANCELED,
    FINISHED
}
